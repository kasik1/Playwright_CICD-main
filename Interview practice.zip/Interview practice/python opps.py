# Encapsulation Example
class Person:
    def __init__(self, name, age):
        self.name = name          # public
        self.__age = age          # private

    def get_age(self):
        return self.__age

    def set_age(self, age):
        if age > 0:
            self.__age = age

# Abstraction Example
from abc import ABC, abstractmethod

class Animal(ABC):
    @abstractmethod
    def sound(self):
        pass

class Dog(Animal):
    def sound(self):
        return "Bark"

# Inheritance Example
class Vehicle:
    def __init__(self, brand):
        self.brand = brand

    def drive(self):
        return f"Driving {self.brand}"

class Car(Vehicle):
    def __init__(self, brand, model):
        super().__init__(brand)
        self.model = model

    def drive(self):
        return f"Driving {self.brand} {self.model}"

# Example usage:
if __name__ == "__main__":
    # Encapsulation
    p = Person("Alice", 30)
    print(p.name)
    print(p.get_age())
    p.set_age(35)
    print(p.get_age())

    # Abstraction
    d = Dog()
    print(d.sound())

    # Inheritance
    c = Car("Toyota", "Corolla")
    print(c.drive())