from selenium import webdriver

# 1. Singleton Pattern for WebDriver
class WebDriverSingleton:
    _instance = None

    @staticmethod
    def get_instance():
        if WebDriverSingleton._instance is None:
            WebDriverSingleton._instance = webdriver.Chrome()  # or webdriver.Firefox()
        return WebDriverSingleton._instance

# Usage:
# driver = WebDriverSingleton.get_instance()

# 2. Abstract Factory Pattern for Page Objects
class PageFactory:
    @staticmethod
    def get_page(page_name, driver):
        if page_name == "login":
            return LoginPage(driver)
        elif page_name == "home":
            return HomePage(driver)
        else:
            raise Exception("Unknown page")

# 3. Page Object Model (POM) Example
class LoginPage:
    def __init__(self, driver):
        self.driver = driver

    def enter_username(self, username):
        self.driver.find_element("id", "username").send_keys(username)

    def enter_password(self, password):
        self.driver.find_element("id", "password").send_keys(password)

    def click_login(self):
        self.driver.find_element("id", "loginBtn").click()

class HomePage:
    def __init__(self, driver):
        self.driver = driver

    def get_welcome_message(self):
        return self.driver.find_element("id", "welcome").text

# Example usage:
if __name__ == "__main__":
    driver = WebDriverSingleton.get_instance()
    driver.get("https://example.com/login")
    login_page = PageFactory.get_page("login", driver)
    login_page.enter_username("user")
    login_page.enter_password("pass")
    login_page.click_login()
    home_page = PageFactory.get_page("home", driver)
    print(home_page.get_welcome_message())
    driver.quit()