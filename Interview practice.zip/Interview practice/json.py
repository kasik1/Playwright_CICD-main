import requests

class NegativeBalanceException(Exception):
    pass

class APIClient:
    def __init__(self, base_url, username, password):
        self.base_url = base_url
        self.username = username
        self.password = password
        self.token = self.authenticate()

    def authenticate(self):
        resp = requests.post(f"{self.base_url}/login", json={"username": self.username, "password": self.password})
        resp.raise_for_status()
        return resp.json()["token"]

    def refresh_token(self):
        self.token = self.authenticate()

    def create_account(self, data):
        headers = {"Authorization": f"Bearer {self.token}"}
        resp = requests.post(f"{self.base_url}/accounts", json=data, headers=headers)
        if resp.status_code == 401:  # Token expired
            self.refresh_token()
            headers["Authorization"] = f"Bearer {self.token}"
            resp = requests.post(f"{self.base_url}/accounts", json=data, headers=headers)
        resp.raise_for_status()
        return resp.json()

    def send_amount(self, from_acc, to_acc, amount):
        if amount < 0:
            raise NegativeBalanceException("Cannot send negative amount")
        headers = {"Authorization": f"Bearer {self.token}"}
        data = {"from": from_acc, "to": to_acc, "amount": amount}
        resp = requests.post(f"{self.base_url}/transfer", json=data, headers=headers)
        if resp.status_code == 401:  # Token expired
            self.refresh_token()
            headers["Authorization"] = f"Bearer {self.token}"
            resp = requests.post(f"{self.base_url}/transfer", json=data, headers=headers)
        if resp.status_code == 400 and "negative balance" in resp.text.lower():
            raise NegativeBalanceException("Insufficient balance")
        resp.raise_for_status()
        return resp.json()

# Example usage:
if __name__ == "__main__":
    client = APIClient("https://api.example.com", "user", "pass")
    try:
        acc = client.create_account({"name": "John"})
        print("Account created:", acc)
        result = client.send_amount(acc["id"], "receiver_id", 100)
        print("Transfer result:", result)
    except NegativeBalanceException as e:
        print("Error:", e)
    except requests.HTTPError as e:
        print("HTTP error:", e)

        ### 11. **How do you use selectors (CSS, XPath, text) in Playwright?**

You can use different selector types:
```csharp
await page.ClickAsync("button#submit"); // CSS
await page.ClickAsync("xpath=//button[text()='Submit']"); // XPath
await page.ClickAsync("text=Submit"); // Text selector
```

---

### 12. **How do you run Playwright tests in parallel?**

Use separate browser contexts or use a test runner like NUnit/xUnit with [Parallelizable] attribute:
```csharp
// Example with NUnit
[Test, Parallelizable]
public async Task Test1() { /* ... */ }
```
Playwright contexts are isolated, so you can run tests in parallel safely.

---

### 13. **How do you mock API responses or intercept network requests in Playwright?**

```csharp
await page.RouteAsync("**/api/data", async route =>
{
    await route.FulfillAsync(new RouteFulfillOptions
    {
        Status = 200,
        Body = "{\"mocked\":true}"
    });
});
await page.GotoAsync("https://yourapp.com");
```

---

### 14. **How do you handle authentication (login flows) in Playwright?**

Automate login and save authentication state:
```csharp
await page.GotoAsync("https://yourapp.com/login");
await page.FillAsync("#user", "username");
await page.FillAsync("#pass", "password");
await page.ClickAsync("#login");
await page.Context.StorageStateAsync(new BrowserContextStorageStateOptions { Path = "auth.json" });
```
Reuse the state in future tests:
```csharp
var context = await browser.NewContextAsync(new BrowserNewContextOptions { StorageStatePath = "auth.json" });
```

---

### 15. **How do you integrate Playwright with test frameworks like NUnit or xUnit in C#?**

Install Microsoft.Playwright.NUnit or use Playwright in your test setup:
```csharp
using NUnit.Framework;
using Microsoft.Playwright;

[TestFixture]
public class PlaywrightTests
{
    [Test]
    public async Task ExampleTest()
    {
        using var playwright = await Playwright.CreateAsync();
        await using var browser = await playwright.Chromium.LaunchAsync();
        var page = await browser.NewPageAsync();
        await page.GotoAsync("https://example.com");
        Assert.That(await page.TitleAsync(), Is.EqualTo("Example Domain"));
    }
}
```