# def is_prime(n):
#     if n <= 1:
#         return False
#     for i in range(2, int(n**0.5)+1):
#         res=n % i
#         print(res)
#         if n % i == 0:

#             print(f"{n} is not prime because it is divisible by {i}")
#             return False
#     return True
# is_prime(4)

# 1. Check if a number is prime
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True

# 2. Find factorial of a number
def factorial(n):
    if n == 0 or n == 1:
        return 1
    return n * factorial(n-1)

# 3. Fibonacci sequence up to n terms
def fibonacci(n):
    seq = []
    a, b = 0, 1
    for _ in range(n):
        seq.append(a)
        a, b = b, a + b
    return seq

# 4. Reverse a string
def reverse_string(s):
    return s[::-1]

# 5. Check if a string is a palindrome
def is_palindrome(s):
    return s == s[::-1]

# 6. Find the largest element in a list
def find_largest(lst):
    return max(lst)

# 7. Find the second largest element in a list
def find_second_largest(lst):
    unique_lst = list(set(lst))
    unique_lst.sort()
    return unique_lst[-2] if len(unique_lst) >= 2 else None

# 8. Remove duplicates from a list
def remove_duplicates(lst):
    return list(set(lst))

# 9. Sum of digits of a number
def sum_of_digits(n):
    return sum(int(digit) for digit in str(abs(n)))

# 10. Swap two variables
def swap(a, b):
    return b, a

# Example usage:
if __name__ == "__main__":
    print("Is 7 prime?", is_prime(7))
    print("Factorial of 5:", factorial(5))
    print("Fibonacci (first 7):", fibonacci(7))
    print("Reverse 'hello':", reverse_string("hello"))
    print("Is 'madam' palindrome?", is_palindrome("madam"))
    print("Largest in [1, 5, 2]:", find_largest([1, 5, 2]))
    print("Second largest in [1, 5, 2, 5]:", find_second_largest([1, 5, 2, 5]))
    print("Remove duplicates from [1,2,2,3]:", remove_duplicates([1,2,2,3]))
    print("Sum of digits of 1234:", sum_of_digits(1234))
    a, b = 3, 4
    a, b = swap(a, b)
    print("Swapped: a =", a, ", b =", b)