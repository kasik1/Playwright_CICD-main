import requests

class NegativeBalanceException(Exception):
    pass

class APIClient:
    def __init__(self, base_url, username, password):
        self.base_url = base_url
        self.username = username
        self.password = password
        self.token = self.authenticate()

    def authenticate(self):
        resp = requests.post(f"{self.base_url}/login", json={"username": self.username, "password": self.password})
        resp.raise_for_status()
        return resp.json()["token"]

    def refresh_token(self):
        self.token = self.authenticate()

    def create_account(self, data):
        headers = {"Authorization": f"Bearer {self.token}"}
        resp = requests.post(f"{self.base_url}/accounts", json=data, headers=headers)
        if resp.status_code == 401:  # Token expired
            self.refresh_token()
            headers["Authorization"] = f"Bearer {self.token}"
            resp = requests.post(f"{self.base_url}/accounts", json=data, headers=headers)
        resp.raise_for_status()
        return resp.json()

    def send_amount(self, from_acc, to_acc, amount):
        if amount < 0:
            raise NegativeBalanceException("Cannot send negative amount")
        headers = {"Authorization": f"Bearer {self.token}"}
        data = {"from": from_acc, "to": to_acc, "amount": amount}
        resp = requests.post(f"{self.base_url}/transfer", json=data, headers=headers)
        if resp.status_code == 401:  # Token expired
            self.refresh_token()
            headers["Authorization"] = f"Bearer {self.token}"
            resp = requests.post(f"{self.base_url}/transfer", json=data, headers=headers)
        if resp.status_code == 400 and "negative balance" in resp.text.lower():
            raise NegativeBalanceException("Insufficient balance")
        resp.raise_for_status()
        return resp.json()

# Example usage:
if __name__ == "__main__":
    client = APIClient("https://api.example.com", "user", "pass")
    try:
        acc = client.create_account({"name": "John"})
        print("Account created:", acc)
        result = client.send_amount(acc["id"], "receiver_id", 100)
        print("Transfer result:", result)
    except NegativeBalanceException as e:
        print("Error:", e)
    except requests.HTTPError as e:
        print("HTTP error:", e)