# 1. Reverse a string
def reverse_string(s):
    return s[::-1]

# 2. Check if a string is a palindrome
def is_palindrome(s):
    return s == s[::-1]

# 3. Count vowels and consonants in a string
def count_vowels_consonants(s):
    vowels = 'aeiouAEIOU'
    v = c = 0
    for char in s:
        if char.isalpha():
            if char in vowels:
                v += 1
            else:
                c += 1
    return v, c

# 4. Find duplicate characters in a string
def find_duplicates(s):
    from collections import Counter
    return [char for char, count in Counter(s).items() if count > 1]

# 5. Check if two strings are anagrams
def are_anagrams(s1, s2):
    return sorted(s1) == sorted(s2)

# 6. Remove all whitespaces from a string
def remove_whitespace(s):
    return s.replace(" ", "")

# 7. Capitalize first letter of each word
def capitalize_words(s):
    return s.title()

# 8. Count the occurrence of each character
def char_frequency(s):
    from collections import Counter
    return dict(Counter(s))

# 9. Replace all vowels with '*'
def replace_vowels(s):
    vowels = 'aeiouAEIOU'
    return ''.join(['*' if char in vowels else char for char in s])

# 10. Check if a string contains only digits
def is_digit_only(s):
    return s.isdigit()

# Example usage:
if __name__ == "__main__":
    s = "hello world"
    print("Reverse:", reverse_string(s))
    print("Is palindrome:", is_palindrome("madam"))
    v, c = count_vowels_consonants(s)
    print("Vowels:", v, "Consonants:", c)
    print("Duplicates:", find_duplicates("programming"))
    print("Are 'listen' and 'silent' anagrams?", are_anagrams("listen", "silent"))
    print("No whitespace:", remove_whitespace(s))
    print("Capitalized:", capitalize_words(s))
    print("Char frequency:", char_frequency(s))
    print("Replace vowels:", replace_vowels(s))
    print("Is '12345' digit only?", is_digit_only("12345"))